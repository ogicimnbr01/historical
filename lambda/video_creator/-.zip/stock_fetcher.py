"""
Historical Image Generator using AWS Bedrock Titan
Generates vintage-style historical images for YouTube Shorts
Uses AI image generation with Ken Burns effect for video output
All content is AI-generated and copyright-safe
"""

import os
import requests
import tempfile
import time
import uuid
import json
import base64
import boto3
from typing import List, Tuple, Optional

# Import copyright safety module
from copyright_safety import get_copyright_tracker, reset_copyright_tracker


# Global counter for unique file names
_fallback_counter = 0

# Era-specific prompt suffixes for authentic historical look
# Ancient/Medieval: Oil painting style (no grain - cameras didn't exist)
# 19th century onwards: Photograph style with appropriate grain
ERA_STYLE_SUFFIXES = {
    "ancient": ", classical oil painting on canvas, ancient world artistic style, marble and bronze aesthetic, dramatic chiaroscuro lighting, museum masterpiece quality",
    "medieval": ", medieval oil painting on canvas texture, castle and knight era, rich colors, dramatic shadows, illuminated manuscript style",
    "ottoman": ", Ottoman oriental painting style, oil on canvas, Islamic geometric patterns, palace interior aesthetic, golden warm tones, miniature painting influence",
    "renaissance": ", Renaissance masterpiece oil painting, canvas texture visible, European court aesthetic, chiaroscuro lighting, museum quality",
    "18th_century": ", 18th century portrait oil painting, canvas texture, colonial era, classical composition, formal dignified",
    "19th_century": ", vintage 19th century photograph style, sepia toned, Victorian era, slightly faded, subtle film grain",
    "early_20th": ", 1920s-1940s black and white vintage photograph, film grain texture, slightly noisy, historical archive look",
    "ww1": ", World War I era photograph, grainy black and white, war documentary style, dramatic, film grain",
    "ww2": ", World War II era photograph, black and white film grain, military documentary style, noisy film",
    "modern": ", mid-20th century color photograph, vintage film look, 1950s-1970s aesthetic, slight color fade"
}

# Default archive style suffix (for unspecified eras)
DEFAULT_ARCHIVE_STYLE = ", vintage archive photograph style, historical, dramatic lighting, photorealistic, slightly aged look"

# Known historical figures that need face-avoidance to prevent AI hallucination
FACE_AVOIDANCE_FIGURES = [
    "atatürk", "ataturk", "mustafa kemal", "fatih", "mehmed", "suleiman", "süleyman",
    "napoleon", "hitler", "stalin", "churchill", "roosevelt", "lincoln", "caesar",
    "cleopatra", "alexander", "genghis", "saladin", "richard", "victoria"
]

# Face-avoidance techniques to add when known figures detected
FACE_AVOIDANCE_TECHNIQUES = [
    "wide shot from distance",
    "dramatic silhouette against light",
    "view from behind looking at horizon",
    "artistic shadow obscuring features",
    "cinematic wide angle shot",
    "figure in dramatic backlight"
]


def enhance_prompt_for_era(prompt: str, era: str = None) -> str:
    """
    Enhance an image prompt with era-appropriate styling
    Also applies face-avoidance for known historical figures to prevent AI hallucination
    
    Args:
        prompt: Base image generation prompt
        era: Historical era for styling (ancient, medieval, ottoman, etc.)
        
    Returns:
        Enhanced prompt with era-specific styling and face-avoidance if needed
    """
    import random
    
    prompt_lower = prompt.lower()
    
    # Check if prompt contains known historical figures
    needs_face_avoidance = any(figure in prompt_lower for figure in FACE_AVOIDANCE_FIGURES)
    
    if needs_face_avoidance:
        # Add face-avoidance technique to prevent uncanny valley
        avoidance = random.choice(FACE_AVOIDANCE_TECHNIQUES)
        prompt = f"{prompt}, {avoidance}"
        print(f"🎭 Face avoidance applied: {avoidance}")
    
    # Get era-specific suffix or use default
    era_suffix = ERA_STYLE_SUFFIXES.get(era, DEFAULT_ARCHIVE_STYLE)
    
    # Ensure 9:16 vertical composition for Shorts
    if "9:16" not in prompt.lower() and "vertical" not in prompt.lower():
        prompt += ", 9:16 vertical composition for mobile"
    
    # Add era styling
    enhanced = prompt + era_suffix
    
    print(f"🎨 Enhanced prompt for era '{era}': {enhanced[:80]}...")
    
    return enhanced


def fetch_videos_by_segments(segments: List[dict], era: str = None, api_key: str = None) -> List[str]:
    """
    Generate videos for each script segment using AI image generation
    Each segment gets a matching historical image converted to video
    
    Args:
        segments: List of segment dicts with 'image_prompt', 'start', 'end', 'text' keys
        era: Optional era for visual styling override
        api_key: Not used (kept for backward compatibility)
        
    Returns:
        List of local file paths to generated videos (one per segment)
    """
    video_paths = []
    
    for i, segment in enumerate(segments):
        # Get the image prompt from segment (new format) or fall back to query (old format)
        image_prompt = segment.get('image_prompt') or segment.get('query', 'historical scene')
        
        # Enhance prompt with era styling
        segment_era = era or segment.get('era', 'early_20th')
        enhanced_prompt = enhance_prompt_for_era(image_prompt, segment_era)
        
        print(f"🔍 Segment {i}: Generating historical image...")
        
        try:
            # Generate AI video from prompt
            video_path = generate_historical_video(enhanced_prompt, segment_index=i)
            
            if video_path:
                video_paths.append(video_path)
                print(f"✅ Segment {i}: Generated historical video -> {video_path}")
            else:
                # Fallback to gradient if AI fails
                print(f"⚠️ Segment {i}: AI failed, using gradient fallback")
                fallback = create_gradient_fallback(i)
                if fallback:
                    video_paths.append(fallback)
                    
        except Exception as e:
            print(f"❌ Segment {i}: Error generating video: {e}")
            fallback = create_gradient_fallback(i)
            if fallback:
                video_paths.append(fallback)
    
    return video_paths


def generate_historical_video(prompt: str, segment_index: int = 0) -> Optional[str]:
    """
    Generate a historical image using AWS Bedrock Titan and convert to video
    Applies Ken Burns effect and old film aesthetic
    
    Args:
        prompt: Image generation prompt
        segment_index: Segment index for unique file naming
        
    Returns:
        Path to generated video file or None if failed
    """
    global _fallback_counter
    import subprocess
    import random
    
    try:
        # Initialize Bedrock client
        region = os.environ.get('AWS_REGION_NAME', 'us-east-1')
        bedrock = boto3.client(
            service_name='bedrock-runtime',
            region_name=region
        )
        
        print(f"🎨 Generating AI image: {prompt[:100]}...")
        
        # Request body for Titan Image Generator
        request_body = {
            "taskType": "TEXT_IMAGE",
            "textToImageParams": {
                "text": prompt
            },
            "imageGenerationConfig": {
                "numberOfImages": 1,
                "height": 1408,  # Closest to 9:16 aspect ratio supported
                "width": 768,
                "cfgScale": 8.0,
                "seed": random.randint(0, 2147483647)
            }
        }
        
        response = bedrock.invoke_model(
            modelId="amazon.titan-image-generator-v1",
            body=json.dumps(request_body),
            contentType="application/json",
            accept="application/json"
        )
        
        response_body = json.loads(response['body'].read())
        images = response_body.get('images', [])
        
        if not images:
            print("⚠️ No images returned from Titan")
            return None
        
        # Decode base64 image
        image_data = base64.b64decode(images[0])
        
        _fallback_counter += 1
        unique_id = f"hist_{segment_index}_{_fallback_counter}_{uuid.uuid4().hex[:6]}"
        
        # Save image
        image_path = os.path.join(tempfile.gettempdir(), f"{unique_id}.png")
        with open(image_path, 'wb') as f:
            f.write(image_data)
        
        print(f"✅ AI image saved: {image_path}")
        
        # Convert image to video with Ken Burns effect + old film look
        video_path = os.path.join(tempfile.gettempdir(), f"{unique_id}.mp4")
        
        # Ken Burns effect: slow zoom for cinematic feel
        # Old film effect: noise + slight desaturation + vignette
        cmd = [
            get_ffmpeg_path(),
            '-y',
            '-loop', '1',
            '-i', image_path,
            '-vf', (
                # Scale and crop for 1080x1920
                f"scale=1080:1920:force_original_aspect_ratio=increase,"
                f"crop=1080:1920,"
                # Ken Burns effect - very slow zoom for documentary feel
                f"zoompan=z='min(zoom+0.0003,1.08)':x='iw/2-(iw/zoom/2)':y='ih/2-(ih/zoom/2)':d=150:s=1080x1920:fps=30,"
                # Old film aesthetic: slight noise, desaturation, vignette
                f"noise=alls=8:allf=t,"  # Film grain
                f"eq=saturation=0.85,"    # Slight desaturation for vintage feel
                f"vignette=PI/4"          # Edge darkening
            ),
            '-c:v', 'libx264',
            '-preset', 'fast',
            '-pix_fmt', 'yuv420p',
            '-t', '5',  # 5 second clip
            video_path
        ]
        
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=120)
        
        if result.returncode == 0 and os.path.exists(video_path):
            file_size = os.path.getsize(video_path)
            if file_size > 10000:
                # Track as AI-generated content (copyright-safe)
                tracker = get_copyright_tracker()
                tracker.add_fallback_video(video_path)
                
                # Cleanup image file
                try:
                    os.remove(image_path)
                except:
                    pass
                
                print(f"✅ Historical video created: {video_path} ({file_size} bytes)")
                return video_path
        
        print(f"⚠️ FFmpeg failed: {result.stderr[:200] if result.stderr else 'unknown'}")
        return None
        
    except Exception as e:
        print(f"⚠️ Historical image generation error: {e}")
        return None


def create_gradient_fallback(index: int = 0) -> Optional[str]:
    """
    Create a gradient/color based fallback video
    Used when AI generation fails
    Uses dark, historical-feeling colors
    """
    global _fallback_counter
    import subprocess
    
    # Historical aesthetic colors (dark, aged look)
    gradient_configs = [
        ("0x1a1611", "dark_parchment"),   # Dark aged paper
        ("0x2c2416", "old_sepia"),        # Sepia brown
        ("0x1f1a14", "antique_brown"),    # Antique dark
        ("0x14171a", "steel_gray"),       # Cold steel (for war topics)
        ("0x1a1820", "dark_violet"),      # Royal purple-ish
        ("0x111a14", "forest_dark"),      # Dark forest green
    ]
    
    _fallback_counter += 1
    unique_id = f"grad_{_fallback_counter}_{uuid.uuid4().hex[:6]}"
    temp_path = os.path.join(tempfile.gettempdir(), f"{unique_id}.mp4")
    
    try:
        color_config = gradient_configs[index % len(gradient_configs)]
        color = color_config[0]
        input_str = f"color=c={color}:s=1080x1920:d=5:r=30"
        
        cmd = [
            get_ffmpeg_path(),
            '-y',
            '-f', 'lavfi',
            '-i', input_str,
            '-vf', 'vignette=PI/4',  # Add vignette for historical feel
            '-c:v', 'libx264',
            '-preset', 'ultrafast',
            '-pix_fmt', 'yuv420p',
            '-t', '5',
            temp_path
        ]
        
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=60)
        
        if result.returncode == 0 and os.path.exists(temp_path):
            file_size = os.path.getsize(temp_path)
            if file_size > 1000:
                tracker = get_copyright_tracker()
                tracker.add_fallback_video(temp_path)
                
                print(f"✅ Gradient fallback created: {temp_path} ({file_size} bytes)")
                return temp_path
        
        print(f"⚠️ Gradient fallback failed: {result.stderr[:200] if result.stderr else 'unknown'}")
        return None
        
    except Exception as e:
        print(f"⚠️ Error creating gradient fallback: {e}")
        return None


def create_animated_fallbacks(count: int, query: str = None) -> List[str]:
    """
    Create fallback videos when main generation fails
    Backward compatible function
    """
    video_paths = []
    
    for i in range(count):
        if query:
            # Try AI generation with the query
            video = generate_historical_video(query, segment_index=i)
            if video:
                video_paths.append(video)
                continue
        
        # Fall back to gradient
        gradient_video = create_gradient_fallback(i)
        if gradient_video:
            video_paths.append(gradient_video)
    
    return video_paths


def fetch_stock_videos(keywords: List[str], num_clips: int = 3, api_key: str = None) -> List[str]:
    """
    Backward compatible function - now generates AI images instead of fetching stock
    
    Args:
        keywords: List of search keywords (used as prompts)
        num_clips: Number of video clips to generate
        api_key: Not used (kept for compatibility)
        
    Returns:
        List of local file paths to generated videos
    """
    video_paths = []
    
    for i, keyword in enumerate(keywords[:num_clips]):
        # Enhance keyword as a prompt
        prompt = f"{keyword}, historical scene, dramatic lighting"
        video = generate_historical_video(prompt, segment_index=i)
        
        if video:
            video_paths.append(video)
        else:
            fallback = create_gradient_fallback(i)
            if fallback:
                video_paths.append(fallback)
    
    # Fill remaining with fallbacks if needed
    while len(video_paths) < num_clips:
        fallback = create_gradient_fallback(len(video_paths))
        if fallback:
            video_paths.append(fallback)
        else:
            break
    
    return video_paths


def get_ffmpeg_path() -> str:
    """Get FFmpeg binary path"""
    if os.path.exists("/opt/bin/ffmpeg"):
        return "/opt/bin/ffmpeg"
    return "ffmpeg"


def get_video_duration(video_path: str) -> float:
    """Get video duration using ffprobe"""
    import subprocess
    
    ffprobe_path = "/opt/bin/ffprobe" if os.path.exists("/opt/bin/ffprobe") else "ffprobe"
    
    cmd = [
        ffprobe_path, '-v', 'quiet',
        '-show_entries', 'format=duration',
        '-of', 'default=noprint_wrappers=1:nokey=1',
        video_path
    ]
    
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
        return float(result.stdout.strip())
    except:
        return 5.0  # Default duration


# Legacy function aliases for backward compatibility
def enhance_query(query: str) -> str:
    """Legacy function - now enhances as historical prompt"""
    return enhance_prompt_for_era(query, "early_20th")

def filter_keywords(keywords: List[str]) -> List[str]:
    """Legacy function - returns keywords as-is"""
    return keywords

def generate_ai_video_fallback(query: str = None) -> Optional[str]:
    """Legacy function - now calls generate_historical_video"""
    return generate_historical_video(query or "historical scene, vintage photograph style")


if __name__ == "__main__":
    # Test locally
    print("Testing Historical Image Generator...")
    
    # Test with a historical prompt
    test_prompt = "Mustafa Kemal Atatürk at dinner table, 1930s, modest Turkish home"
    video = generate_historical_video(test_prompt)
    
    if video:
        print(f"Generated: {video}")
    else:
        print("Generation failed, testing fallback...")
        fallback = create_gradient_fallback(0)
        print(f"Fallback: {fallback}")
