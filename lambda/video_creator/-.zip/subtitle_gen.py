"""
Subtitle Generator for Calm Life YouTube Shorts
Creates ASS (Advanced SubStation Alpha) subtitle files
Minimal, clean styling - white text, small font, gentle fade
"""

import os
import tempfile
from typing import List, Tuple
import uuid
import re


# MINIMAL STYLE - Clean, gentle, authentic
# Calm Life aesthetic: Small font, white, soft shadow
CALM_STYLE = """
[Script Info]
Title: Calm Life Subtitles
ScriptType: v4.00+
WrapStyle: 0
ScaledBorderAndShadow: yes
YCbCr Matrix: None
PlayResX: 1080
PlayResY: 1920

[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: Default,Arial,60,&H00FFFFFF,&H000000FF,&H00000000,&H80000000,0,0,0,0,100,100,0,0,1,2,1,2,50,50,150,1

[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
"""


def format_ass_time(seconds: float) -> str:
    """Convert seconds to ASS time format (H:MM:SS.CC)"""
    hours = int(seconds // 3600)
    minutes = int((seconds % 3600) // 60)
    secs = int(seconds % 60)
    centisecs = int((seconds - int(seconds)) * 100)
    return f"{hours}:{minutes:02d}:{secs:02d}.{centisecs:02d}"


def create_subtitle_file(
    title: str,
    narration_text: str,
    total_duration: float
) -> str:
    """
    Create an ASS subtitle file with MINIMAL, CALM styling
    
    Args:
        title: Video title (not displayed - keeping it minimal)
        narration_text: Full narration text
        total_duration: Total video duration in seconds
        
    Returns:
        Path to the created ASS subtitle file
    """
    unique_id = uuid.uuid4().hex[:8]
    subtitle_path = os.path.join(tempfile.gettempdir(), f"subtitles_{unique_id}.ass")
    
    events = []
    
    # Split text into logical segments (by punctuation)
    # Calm content = longer phrases, not word-by-word
    segments = re.split(r'([.?!])', narration_text)
    
    # Recombine segments with their punctuation
    phrases = []
    current_phrase = ""
    
    for seg in segments:
        current_phrase += seg
        if seg in '.?!':
            if current_phrase.strip():
                phrases.append(current_phrase.strip())
            current_phrase = ""
            
    if current_phrase.strip():
        phrases.append(current_phrase.strip())
        
    # If no phrases, use the whole text
    if not phrases:
        phrases = [narration_text]
        
    # Calculate timing - longer display for calm reading
    phrase_duration = total_duration / len(phrases)
    
    for i, phrase in enumerate(phrases):
        start_time = i * phrase_duration
        end_time = (i + 1) * phrase_duration
        
        # Add gentle fade effect (400ms - slower for calm feel)
        safe_phrase = escape_ass_text(phrase)
        events.append(
            f"Dialogue: 0,{format_ass_time(start_time)},{format_ass_time(end_time)},Default,,0,0,0,,{{\\fad(400,400)}}{safe_phrase}"
        )
    
    # Write the ASS file
    with open(subtitle_path, 'w', encoding='utf-8') as f:
        f.write(CALM_STYLE)
        f.write('\n'.join(events))
        f.write('\n')
    
    print(f"✅ Created calm subtitle file: {subtitle_path}")
    return subtitle_path


def escape_ass_text(text: str) -> str:
    """Escape special characters for ASS format"""
    # Replace newlines with ASS newline
    text = text.replace('\n', '\\N')
    # Escape backslashes (but not our escaped newlines)
    text = text.replace('\\N', '<<<NEWLINE>>>')
    text = text.replace('\\', '\\\\')
    text = text.replace('<<<NEWLINE>>>', '\\N')
    # Remove or escape other special characters
    text = text.replace('{', '\\{')
    text = text.replace('}', '\\}')
    return text


def create_simple_subtitle(text: str, duration: float) -> str:
    """
    Create a simple single-line subtitle file
    For when you just need basic text overlay
    """
    unique_id = uuid.uuid4().hex[:8]
    subtitle_path = os.path.join(tempfile.gettempdir(), f"simple_sub_{unique_id}.ass")
    
    safe_text = escape_ass_text(text[:80])  # Limit length
    
    content = CALM_STYLE + f"Dialogue: 0,{format_ass_time(0)},{format_ass_time(duration)},Default,,0,0,0,,{{\\fad(500,500)}}{safe_text}\n"
    
    with open(subtitle_path, 'w', encoding='utf-8') as f:
        f.write(content)
    
    return subtitle_path


if __name__ == "__main__":
    # Test subtitle generation
    path = create_subtitle_file(
        title="🌙 Long day?",
        narration_text="Mind feels loud? You don't have to solve anything right now. Just breathe.",
        total_duration=10.0
    )
    print(f"Created: {path}")
    
    # Print contents
    with open(path, 'r') as f:
        print(f.read())
